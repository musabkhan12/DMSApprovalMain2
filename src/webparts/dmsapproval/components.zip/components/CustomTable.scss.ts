/* tslint:disable */
require("./CustomTable.css");
const styles = {

};

export default styles;
/* tslint:enable */