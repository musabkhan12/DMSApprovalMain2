/* tslint:disable */
require("./Dmsapproval.module.css");
const styles = {
  dmsapproval: 'dmsapproval_7e8b0fc3',
  teams: 'teams_7e8b0fc3',
  welcome: 'welcome_7e8b0fc3',
  welcomeImage: 'welcomeImage_7e8b0fc3',
  links: 'links_7e8b0fc3'
};

export default styles;
/* tslint:enable */