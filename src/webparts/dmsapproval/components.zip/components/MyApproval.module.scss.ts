/* tslint:disable */
require("./MyApproval.module.css");
const styles = {
  myApproval: 'myApproval_2c735ae9',
  teams: 'teams_2c735ae9',
  welcome: 'welcome_2c735ae9',
  welcomeImage: 'welcomeImage_2c735ae9',
  links: 'links_2c735ae9'
};

export default styles;
/* tslint:enable */